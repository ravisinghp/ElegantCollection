"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart3,
  Users,
  Mail,
  FileText,
  Clock,
  TrendingUp,
  Download,
  RefreshCw,
  AlertCircle,
  Plus,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useActionState } from "react" // Corrected import: from "react"
import { useFormStatus } from "react-dom"
import { createUserAndMailCredentials } from "@/actions/user-management"
import { useToast } from "@/components/ui/use-toast"
import { useEffect } from "react"

export default function DashboardPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [lastSync, setLastSync] = useState(new Date())
  const [isCreateUserDialogOpen, setIsCreateUserDialogOpen] = useState(false)

  const handleManualSync = async () => {
    setIsLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setLastSync(new Date())
    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">R&D Effort Dashboard</h1>
            <p className="text-gray-600 mt-2">Last sync: {lastSync.toLocaleString()}</p>
          </div>
          <div className="flex space-x-4">
            <Button onClick={handleManualSync} disabled={isLoading} variant="outline">
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
              {isLoading ? "Syncing..." : "Manual Sync"}
            </Button>
            <Button>
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Total R&D Effort"
            value="2,340 hrs"
            change="+12%"
            icon={<Clock className="h-5 w-5" />}
            trend="up"
          />
          <MetricCard title="Active Users" value="24" change="+3" icon={<Users className="h-5 w-5" />} trend="up" />
          <MetricCard
            title="Emails Processed"
            value="1,847"
            change="+156"
            icon={<Mail className="h-5 w-5" />}
            trend="up"
          />
          <MetricCard
            title="Documents Analyzed"
            value="432"
            change="+28"
            icon={<FileText className="h-5 w-5" />}
            trend="up"
          />
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="keywords">Keywords</TabsTrigger>
            <TabsTrigger value="workflow">Workflow Status</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Effort Trends</CardTitle>
                  <CardDescription>R&D effort over the last 30 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    <BarChart3 className="h-16 w-16" />
                    <span className="ml-4">Chart visualization would go here</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Top Keywords</CardTitle>
                  <CardDescription>Most frequently detected R&D keywords</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <KeywordItem keyword="Machine Learning" count={89} />
                    <KeywordItem keyword="Data Analysis" count={67} />
                    <KeywordItem keyword="Algorithm" count={54} />
                    <KeywordItem keyword="Research" count={43} />
                    <KeywordItem keyword="Innovation" count={32} />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>User Activity</CardTitle>
                  <CardDescription>R&D effort by team member</CardDescription>
                </div>
                <Dialog open={isCreateUserDialogOpen} onOpenChange={setIsCreateUserDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Create New User
                    </Button>
                  </DialogTrigger>
                  <CreateUserDialog onClose={() => setIsCreateUserDialogOpen(false)} />
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <UserActivityItem
                    name="Sarah Johnson"
                    role="Senior Researcher"
                    effort="156 hrs"
                    emails={89}
                    status="active"
                  />
                  <UserActivityItem
                    name="Mike Chen"
                    role="Data Scientist"
                    effort="134 hrs"
                    emails={76}
                    status="active"
                  />
                  <UserActivityItem
                    name="Emily Davis"
                    role="Research Analyst"
                    effort="98 hrs"
                    emails={54}
                    status="active"
                  />
                  <UserActivityItem
                    name="Alex Rodriguez"
                    role="ML Engineer"
                    effort="87 hrs"
                    emails={43}
                    status="warning"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="keywords" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Keyword Management</CardTitle>
                <CardDescription>Configure R&D keywords and their weights</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <KeywordConfigItem
                    keyword="Artificial Intelligence"
                    weight={20}
                    category="Technology"
                    matches={156}
                  />
                  <KeywordConfigItem keyword="Machine Learning" weight={18} category="Technology" matches={134} />
                  <KeywordConfigItem keyword="Data Science" weight={15} category="Analytics" matches={98} />
                  <KeywordConfigItem keyword="Research Methodology" weight={12} category="Process" matches={67} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="workflow" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Processing Status</CardTitle>
                  <CardDescription>Current workflow execution status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <WorkflowStep
                      step="Email Scanning"
                      status="completed"
                      progress={100}
                      description="Last run: 2 hours ago"
                    />
                    <WorkflowStep
                      step="Document Processing"
                      status="running"
                      progress={65}
                      description="Processing 23 documents"
                    />
                    <WorkflowStep
                      step="Keyword Detection"
                      status="pending"
                      progress={0}
                      description="Waiting for document processing"
                    />
                    <WorkflowStep
                      step="Effort Calculation"
                      status="pending"
                      progress={0}
                      description="Scheduled for next run"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>System Health</CardTitle>
                  <CardDescription>Monitor system performance and issues</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <HealthItem component="Email API" status="healthy" uptime="99.9%" />
                    <HealthItem component="Document Parser" status="healthy" uptime="98.7%" />
                    <HealthItem component="NLP Service" status="warning" uptime="95.2%" />
                    <HealthItem component="Database" status="healthy" uptime="100%" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

function MetricCard({
  title,
  value,
  change,
  icon,
  trend,
}: {
  title: string
  value: string
  change: string
  icon: React.ReactNode
  trend: "up" | "down"
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className={`text-xs ${trend === "up" ? "text-green-600" : "text-red-600"}`}>
          <TrendingUp className="h-3 w-3 inline mr-1" />
          {change} from last month
        </p>
      </CardContent>
    </Card>
  )
}

function KeywordItem({ keyword, count }: { keyword: string; count: number }) {
  return (
    <div className="flex justify-between items-center">
      <span className="font-medium">{keyword}</span>
      <Badge variant="secondary">{count}</Badge>
    </div>
  )
}

function UserActivityItem({
  name,
  role,
  effort,
  emails,
  status,
}: {
  name: string
  role: string
  effort: string
  emails: number
  status: "active" | "warning"
}) {
  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div className="flex items-center space-x-4">
        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
          <Users className="h-5 w-5 text-blue-600" />
        </div>
        <div>
          <p className="font-medium">{name}</p>
          <p className="text-sm text-gray-600">{role}</p>
        </div>
      </div>
      <div className="text-right">
        <p className="font-medium">{effort}</p>
        <p className="text-sm text-gray-600">{emails} emails</p>
      </div>
      <Badge variant={status === "active" ? "default" : "destructive"}>{status}</Badge>
    </div>
  )
}

function KeywordConfigItem({
  keyword,
  weight,
  category,
  matches,
}: {
  keyword: string
  weight: number
  category: string
  matches: number
}) {
  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div>
        <p className="font-medium">{keyword}</p>
        <p className="text-sm text-gray-600">{category}</p>
      </div>
      <div className="flex items-center space-x-4">
        <div className="text-right">
          <p className="text-sm">Weight: {weight}min</p>
          <p className="text-sm text-gray-600">{matches} matches</p>
        </div>
        <Button size="sm" variant="outline">
          Edit
        </Button>
      </div>
    </div>
  )
}

function WorkflowStep({
  step,
  status,
  progress,
  description,
}: {
  step: string
  status: "completed" | "running" | "pending"
  progress: number

  description: string
}) {
  const statusColors = {
    completed: "text-green-600",
    running: "text-blue-600",
    pending: "text-gray-400",
  }

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="font-medium">{step}</span>
        <Badge variant={status === "completed" ? "default" : status === "running" ? "secondary" : "outline"}>
          {status}
        </Badge>
      </div>
      <Progress value={progress} className="h-2" />
      <p className={`text-sm ${statusColors[status]}`}>{description}</p>
    </div>
  )
}

function HealthItem({
  component,
  status,
  uptime,
}: {
  component: string
  status: "healthy" | "warning" | "error"
  uptime: string
}) {
  const statusIcons = {
    healthy: <div className="w-3 h-3 bg-green-500 rounded-full" />,
    warning: <AlertCircle className="h-4 w-4 text-yellow-500" />,
    error: <AlertCircle className="h-4 w-4 text-red-500" />,
  }

  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center space-x-3">
        {statusIcons[status]}
        <span className="font-medium">{component}</span>
      </div>
      <span className="text-sm text-gray-600">{uptime}</span>
    </div>
  )
}

function CreateUserDialog({ onClose }: { onClose: () => void }) {
  const [state, formAction] = useActionState(createUserAndMailCredentials, {
    success: false,
    message: "",
    errors: {},
  })
  const { pending } = useFormStatus()
  const { toast } = useToast()

  useEffect(() => {
    if (state.message) {
      toast({
        title: state.success ? "Success!" : "Error!",
        description: state.message,
        variant: state.success ? "default" : "destructive",
      })
      if (state.success) {
        onClose() // Close dialog on successful creation
      }
    }
  }, [state, toast, onClose])

  return (
    <DialogContent className="sm:max-w-[425px]">
      <DialogHeader>
        <DialogTitle>Create New User</DialogTitle>
        <DialogDescription>
          Enter user details. Temporary credentials will be generated and simulated to be emailed.
        </DialogDescription>
      </DialogHeader>
      <form action={formAction}>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Name
            </Label>
            <Input id="name" name="name" className="col-span-3" required />
            {state.errors?.name && <p className="col-span-4 text-right text-sm text-red-500">{state.errors.name}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="email" className="text-right">
              Email
            </Label>
            <Input id="email" name="email" type="email" className="col-span-3" required />
            {state.errors?.email && <p className="col-span-4 text-right text-sm text-red-500">{state.errors.email}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="role" className="text-right">
              Role
            </Label>
            <Select name="role" required>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select a role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="user">User</SelectItem>
              </SelectContent>
            </Select>
            {state.errors?.role && <p className="col-span-4 text-right text-sm text-red-500">{state.errors.role}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="department" className="text-right">
              Department
            </Label>
            <Input id="department" name="department" className="col-span-3" />
            {state.errors?.department && (
              <p className="col-span-4 text-right text-sm text-red-500">{state.errors.department}</p>
            )}
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={pending}>
            {pending ? "Creating..." : "Create User"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  )
}
