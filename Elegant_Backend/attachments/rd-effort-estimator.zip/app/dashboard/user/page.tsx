"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Mail, FileText, Clock, Download, RefreshCw, CheckCircle, XCircle, LinkIcon } from "lucide-react"
import { initiateOAuth, handleOAuthCallback } from "@/actions/email-connection"
import { getUserEmailConnectionStatus } from "@/actions/user-management"
import { useToast } from "@/components/ui/use-toast"
import { useSearchParams } from "next/navigation"

export default function UserDashboardPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [lastSync, setLastSync] = useState(new Date())
  const [emailConnectionStatus, setEmailConnectionStatus] = useState({
    connected: false,
    provider: null,
    lastScan: null,
  })
  const { toast } = useToast()
  const searchParams = useSearchParams()

  // Mock user ID - in a real app, this would come from the authenticated session
  const currentUserId = "mock-user-id"

  useEffect(() => {
    const fetchConnectionStatus = async () => {
      const status = await getUserEmailConnectionStatus(currentUserId)
      setEmailConnectionStatus({
        connected: status.emailConnected,
        provider: status.emailProvider,
        lastScan: status.lastScanDate ? new Date(status.lastScanDate) : null,
      })
    }
    fetchConnectionStatus()

    // Handle OAuth callback
    const code = searchParams.get("code")
    const provider = searchParams.get("provider") // Custom param to identify provider after redirect

    if (code && provider && !emailConnectionStatus.connected) {
      const connectEmail = async () => {
        try {
          const result = await handleOAuthCallback(code, provider as "google" | "microsoft", currentUserId)
          if (result.success) {
            toast({
              title: "Email Connected!",
              description: result.message,
              variant: "default",
            })
            setEmailConnectionStatus({
              connected: true,
              provider: result.provider,
              lastScan: new Date(),
            })
            // Clear URL params after processing
            window.history.replaceState({}, document.title, window.location.pathname)
          } else {
            toast({
              title: "Connection Failed",
              description: result.message,
              variant: "destructive",
            })
          }
        } catch (error: any) {
          toast({
            title: "Connection Error",
            description: error.message || "An unexpected error occurred during connection.",
            variant: "destructive",
          })
        }
      }
      connectEmail()
    }
  }, [searchParams, toast, emailConnectionStatus.connected, currentUserId])

  const handleManualSync = async () => {
    setIsLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setLastSync(new Date())
    setIsLoading(false)
  }

  const handleConnectEmail = async (provider: "google" | "microsoft") => {
    try {
      // This will redirect the user to the OAuth provider
      await initiateOAuth(provider)
    } catch (error: any) {
      toast({
        title: "OAuth Initiation Failed",
        description: error.message || "Could not initiate OAuth flow.",
        variant: "destructive",
      })
    }
  }

  // Mock data for the logged-in user
  const currentUserStats = {
    totalEffort: "180 hrs",
    emailsProcessed: 156,
    documentsAnalyzed: 45,
    rdEmails: 120,
    nonRdEmails: 36,
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">My R&D Effort Dashboard</h1>
            <p className="text-gray-600 mt-2">Last sync: {lastSync.toLocaleString()}</p>
          </div>
          <div className="flex space-x-4">
            <Button onClick={handleManualSync} disabled={isLoading} variant="outline">
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
              {isLoading ? "Syncing..." : "Manual Sync"}
            </Button>
            <Button>
              <Download className="h-4 w-4 mr-2" />
              Export My Report
            </Button>
          </div>
        </div>

        {/* Email Connection Status */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Email Connection</CardTitle>
            <CardDescription>Connect your email to enable R&D effort tracking.</CardDescription>
          </CardHeader>
          <CardContent>
            {emailConnectionStatus.connected ? (
              <div className="flex items-center space-x-2 text-green-600 font-medium">
                <CheckCircle className="h-5 w-5" />
                <span>Connected to {emailConnectionStatus.provider === "google" ? "Gmail" : "Outlook"}</span>
                {emailConnectionStatus.lastScan && (
                  <span className="text-gray-500 text-sm ml-2">
                    (Last scanned: {emailConnectionStatus.lastScan.toLocaleString()})
                  </span>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center space-x-2 text-red-600 font-medium">
                  <XCircle className="h-5 w-5" />
                  <span>Email not connected.</span>
                </div>
                <div className="flex gap-4">
                  <Button onClick={() => handleConnectEmail("google")} className="flex-1">
                    <LinkIcon className="h-4 w-4 mr-2" />
                    Connect with Google
                  </Button>
                  <Button onClick={() => handleConnectEmail("microsoft")} className="flex-1">
                    <LinkIcon className="h-4 w-4 mr-2" />
                    Connect with Microsoft
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Key Metrics for User */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <MetricCard
            title="My Total R&D Effort"
            value={currentUserStats.totalEffort}
            icon={<Clock className="h-5 w-5" />}
          />
          <MetricCard
            title="Emails Processed by Me"
            value={currentUserStats.emailsProcessed.toString()}
            icon={<Mail className="h-5 w-5" />}
          />
          <MetricCard
            title="Documents Analyzed by Me"
            value={currentUserStats.documentsAnalyzed.toString()}
            icon={<FileText className="h-5 w-5" />}
          />
        </div>

        {/* Email Classification */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Email Classification Overview</CardTitle>
            <CardDescription>Breakdown of your emails classified as R&D or Non-R&D</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <EmailClassificationItem
                type="R&D Emails"
                count={currentUserStats.rdEmails}
                total={currentUserStats.emailsProcessed}
                icon={<CheckCircle className="h-5 w-5 text-green-500" />}
              />
              <EmailClassificationItem
                type="Non-R&D Emails"
                count={currentUserStats.nonRdEmails}
                total={currentUserStats.emailsProcessed}
                icon={<XCircle className="h-5 w-5 text-red-500" />}
              />
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity (Placeholder) */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Your most recent R&D related emails and documents</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <RecentActivityItem
                type="Email"
                subject="Meeting notes on AI model optimization"
                date="2024-07-29"
                effort="45 min"
              />
              <RecentActivityItem
                type="Document"
                subject="Research Proposal - Quantum Computing"
                date="2024-07-28"
                effort="90 min"
              />
              <RecentActivityItem
                type="Email"
                subject="Feedback on prototype design"
                date="2024-07-27"
                effort="30 min"
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function MetricCard({
  title,
  value,
  icon,
}: {
  title: string
  value: string
  icon: React.ReactNode
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  )
}

function EmailClassificationItem({
  type,
  count,
  total,
  icon,
}: {
  type: string
  count: number
  total: number
  icon: React.ReactNode
}) {
  const percentage = total > 0 ? Math.round((count / total) * 100) : 0
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2">
          {icon}
          <span className="font-medium">{type}</span>
        </div>
        <Badge variant="secondary">{count} emails</Badge>
      </div>
      <Progress value={percentage} className="h-2" />
      <p className="text-sm text-gray-600">{percentage}% of your processed emails</p>
    </div>
  )
}

function RecentActivityItem({
  type,
  subject,
  date,
  effort,
}: {
  type: string
  subject: string
  date: string
  effort: string
}) {
  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div className="flex items-center space-x-4">
        {type === "Email" ? (
          <Mail className="h-5 w-5 text-blue-600" />
        ) : (
          <FileText className="h-5 w-5 text-purple-600" />
        )}
        <div>
          <p className="font-medium">{subject}</p>
          <p className="text-sm text-gray-600">{date}</p>
        </div>
      </div>
      <Badge variant="outline">{effort}</Badge>
    </div>
  )
}
