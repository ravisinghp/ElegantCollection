import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight, User, UserCog } from "lucide-react"

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-gray-900">Sign In</CardTitle>
          <CardDescription className="text-gray-600">Choose your role to access the dashboard</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Button asChild className="w-full py-6 text-lg">
              <Link href="/dashboard/admin" className="flex items-center justify-center">
                <UserCog className="h-6 w-6 mr-3" />
                Sign In as Admin
                <ArrowRight className="ml-auto h-5 w-5" />
              </Link>
            </Button>
            <Button asChild variant="outline" className="w-full py-6 text-lg bg-transparent">
              <Link href="/dashboard/user" className="flex items-center justify-center">
                <User className="h-6 w-6 mr-3" />
                Sign In as User
                <ArrowRight className="ml-auto h-5 w-5" />
              </Link>
            </Button>
          </div>
          <p className="text-center text-sm text-gray-500">
            By signing in, you agree to our{" "}
            <Link href="#" className="underline">
              Terms of Service
            </Link>{" "}
            and{" "}
            <Link href="#" className="underline">
              Privacy Policy
            </Link>
            .
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
