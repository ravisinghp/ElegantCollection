import type React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Mail, FileText, BarChart3, Users, Shield, Zap } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <BarChart3 className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">R&D Effort Estimator</h1>
          </div>
          <div className="space-x-4">
            <Button variant="ghost" asChild>
              <Link href="/login">Login</Link>
            </Button>
            <Button asChild>
              <Link href="/register">Get Started</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <Badge variant="secondary" className="mb-4">
          Automated R&D Tracking
        </Badge>
        <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
          Transform Email Analysis into
          <span className="text-blue-600"> R&D Insights</span>
        </h2>
        <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
          Automatically analyze emails and documents to calculate R&D effort based on keywords and predefined rules. Get
          comprehensive insights into your team's research and development activities.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" asChild>
            <Link href="/register">
              Start Free Trial <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link href="/demo">View Demo</Link>
          </Button>
        </div>
      </section>

      {/* Workflow Overview */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">How It Works</h3>
          <p className="text-lg text-gray-600">Simple workflow, powerful insights</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <WorkflowStep
            icon={<Mail className="h-8 w-8" />}
            title="Connect Email"
            description="Securely connect your email account via OAuth. We scan your inbox daily for R&D-related content."
            step="1"
          />
          <WorkflowStep
            icon={<FileText className="h-8 w-8" />}
            title="Analyze Content"
            description="AI-powered analysis extracts keywords from emails and attachments (PDF, DOCX, XLSX) using NLP."
            step="2"
          />
          <WorkflowStep
            icon={<BarChart3 className="h-8 w-8" />}
            title="Calculate Effort"
            description="Apply custom rules to estimate R&D effort. View dashboards and export detailed reports."
            step="3"
          />
        </div>
      </section>

      {/* Features Grid */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">Key Features</h3>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <FeatureCard
            icon={<Users className="h-6 w-6" />}
            title="Multi-Tenant Support"
            description="Super Admin creates company accounts, Admins manage users and contractors."
          />
          <FeatureCard
            icon={<Shield className="h-6 w-6" />}
            title="Secure OAuth Integration"
            description="Connect Google or Microsoft email accounts securely without storing credentials."
          />
          <FeatureCard
            icon={<Zap className="h-6 w-6" />}
            title="Automated Scanning"
            description="Daily scheduled jobs scan inbox for new emails and attachments automatically."
          />
          <FeatureCard
            icon={<FileText className="h-6 w-6" />}
            title="Document Processing"
            description="Extract text from PDF, DOCX, XLSX files with OCR support for scanned documents."
          />
          <FeatureCard
            icon={<BarChart3 className="h-6 w-6" />}
            title="Advanced Analytics"
            description="Keyword heatmaps, effort trends, and exportable reports (PDF/Excel)."
          />
          <FeatureCard
            icon={<Mail className="h-6 w-6" />}
            title="Smart Notifications"
            description="Alerts for high R&D activity, scan errors, and missing email access."
          />
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold mb-4">Ready to Get Started?</h3>
          <p className="text-xl mb-8 opacity-90">
            Join companies already using R&D Effort Estimator to track their research activities.
          </p>
          <Button size="lg" variant="secondary" asChild>
            <Link href="/register">
              Start Your Free Trial <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2024 R&D Effort Estimator. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

function WorkflowStep({
  icon,
  title,
  description,
  step,
}: {
  icon: React.ReactNode
  title: string
  description: string
  step: string
}) {
  return (
    <Card className="relative">
      <CardHeader className="text-center">
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center font-bold">
          {step}
        </div>
        <div className="text-blue-600 mb-2 flex justify-center mt-4">{icon}</div>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-center">{description}</CardDescription>
      </CardContent>
    </Card>
  )
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <Card>
      <CardHeader>
        <div className="text-blue-600 mb-2">{icon}</div>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription>{description}</CardDescription>
      </CardContent>
    </Card>
  )
}
