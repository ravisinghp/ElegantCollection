"use server"

import { z } from "zod"
import { v4 as uuidv4 } from "uuid"

// Define schema for user creation
const createUserSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email address"),
  role: z.enum(["admin", "user"], { message: "Role must be 'admin' or 'user'" }),
  department: z.string().optional(),
})

export async function createUserAndMailCredentials(prevState: any, formData: FormData) {
  const data = {
    name: formData.get("name"),
    email: formData.get("email"),
    role: formData.get("role"),
    department: formData.get("department"),
  }

  const validatedFields = createUserSchema.safeParse(data)

  if (!validatedFields.success) {
    return {
      success: false,
      message: "Validation failed",
      errors: validatedFields.error.flatten().fieldErrors,
    }
  }

  const { name, email, role, department } = validatedFields.data

  // Simulate user creation in DB
  const newUserId = uuidv4()
  const temporaryPassword = Math.random().toString(36).substring(2, 10) // Simple temporary password

  console.log(`Simulating user creation:
    ID: ${newUserId}
    Name: ${name}
    Email: ${email}
    Role: ${role}
    Department: ${department || "N/A"}
    Temporary Password: ${temporaryPassword}
  `)

  // Simulate sending email with credentials
  console.log(`Simulating email to ${email} with temporary password: ${temporaryPassword}`)

  // In a real app, you would:
  // 1. Hash the temporaryPassword before storing it
  // 2. Store the new user in your 'users' table
  // 3. Use a transactional email service (e.g., SendGrid, Mailgun) to send the actual email

  return {
    success: true,
    message: `User ${name} created successfully. Credentials simulated to be emailed to ${email}.`,
  }
}

// Mock function to simulate fetching user data (e.g., for current user's email connection status)
export async function getUserEmailConnectionStatus(userId: string) {
  // In a real application, this would fetch from your database
  // For now, let's simulate a connected user
  if (userId === "mock-user-id") {
    return {
      emailConnected: true,
      emailProvider: "google",
      lastScanDate: new Date().toISOString(),
    }
  }
  return {
    emailConnected: false,
    emailProvider: null,
    lastScanDate: null,
  }
}
