"use client"

import type React from "react"
import { useRouter } from "next/navigation"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart3,
  Users,
  Mail,
  FileText,
  Clock,
  TrendingUp,
  Download,
  RefreshCw,
  Plus,
  Edit,
  Save,
  X,
  Calendar,
  Filter,
  LogOut,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useActionState } from "react" // Corrected import: from "react"
import { useFormStatus } from "react-dom"
import { createUserAndMailCredentials } from "@/actions/user-management"
import { useToast } from "@/components/ui/use-toast"
import { useEffect } from "react"
import { Checkbox } from "@/components/ui/checkbox"

export default function DashboardPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [lastSync, setLastSync] = useState(new Date())
  const [isCreateUserDialogOpen, setIsCreateUserDialogOpen] = useState(false)
  const [isCreateKeywordDialogOpen, setIsCreateKeywordDialogOpen] = useState(false)
  const [isCreateBusinessRuleDialogOpen, setIsCreateBusinessRuleDialogOpen] = useState(false)
  const [editingBusinessRule, setEditingBusinessRule] = useState<string | null>(null)
  const [businessRules, setBusinessRules] = useState([
    { id: "1", name: "AI Research Keywords", wordCount: 500, efforts: 120 },
    { id: "2", name: "Data Analysis Projects", wordCount: 300, efforts: 90 },
    { id: "3", name: "Machine Learning Models", wordCount: 800, efforts: 180 },
    { id: "4", name: "Research Documentation", wordCount: 200, efforts: 60 },
  ])
  const [reportData, setReportData] = useState([
    {
      id: "1",
      entityType: "Email",
      date: "2024-01-15",
      sender: "john@company.com",
      recipients: "team@company.com",
      wordCount: 450,
      efforts: 45,
      keywordCount: 8,
      keywordEfforts: 15,
      selected: false,
    },
    {
      id: "2",
      entityType: "Calendar",
      date: "2024-01-14",
      sender: "sarah@company.com",
      recipients: "dev-team@company.com",
      wordCount: 200,
      efforts: 30,
      keywordCount: 5,
      keywordEfforts: 10,
      selected: false,
    },
    {
      id: "3",
      entityType: "Email",
      date: "2024-01-13",
      sender: "mike@company.com",
      recipients: "research@company.com",
      wordCount: 680,
      efforts: 75,
      keywordCount: 12,
      keywordEfforts: 25,
      selected: false,
    },
  ])
  const [dateRange, setDateRange] = useState({ from: "2024-01-01", to: "2024-01-31" })
  const router = useRouter()

  const handleManualSync = async () => {
    setIsLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setLastSync(new Date())
    setIsLoading(false)
  }

  const handleLogout = () => {
    // Clear any session data if needed
    // localStorage.clear() // Uncomment if you store session data
    router.push("/login")
  }

  const handleEditBusinessRule = (id: string) => {
    setEditingBusinessRule(id)
  }

  const handleSaveBusinessRule = (id: string) => {
    setEditingBusinessRule(null)
    // Here you would typically save to backend
  }

  const handleCancelEdit = () => {
    setEditingBusinessRule(null)
  }

  const handleSelectAll = (checked: boolean) => {
    setReportData((prev) => prev.map((item) => ({ ...item, selected: checked })))
  }

  const handleSelectRow = (id: string, checked: boolean) => {
    setReportData((prev) => prev.map((item) => (item.id === id ? { ...item, selected: checked } : item)))
  }

  const handleDownload = (format: "excel" | "pdf") => {
    const selectedRows = reportData.filter((row) => row.selected)
    if (selectedRows.length === 0) {
      alert("Please select at least one row to download")
      return
    }
    // Here you would implement actual download logic
    console.log(`Downloading ${selectedRows.length} rows as ${format}`)
  }

  const handleEffortChange = (id: string, field: "efforts" | "keywordEfforts", value: number) => {
    setReportData((prev) => prev.map((item) => (item.id === id ? { ...item, [field]: value } : item)))
  }

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">R&D Effort Dashboard</h1>
            <p className="text-gray-600 mt-2">Last sync: {lastSync.toLocaleString()}</p>
          </div>
          <div className="flex space-x-4">
            <Button onClick={handleManualSync} disabled={isLoading} variant="outline">
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
              {isLoading ? "Syncing..." : "Manual Sync"}
            </Button>
            <Button onClick={handleLogout} variant="outline">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Total R&D Effort"
            value="2,340 hrs"
            change="+12%"
            icon={<Clock className="h-5 w-5" />}
            trend="up"
          />
          <MetricCard title="Active Users" value="24" change="+3" icon={<Users className="h-5 w-5" />} trend="up" />
          <MetricCard
            title="Emails Processed"
            value="1,847"
            change="+156"
            icon={<Mail className="h-5 w-5" />}
            trend="up"
          />
          <MetricCard
            title="Documents Analyzed"
            value="432"
            change="+28"
            icon={<FileText className="h-5 w-5" />}
            trend="up"
          />
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 [&>*]:hover:bg-gradient-to-r [&>*]:hover:from-orange-500 [&>*]:hover:to-yellow-500 [&>*]:hover:text-white [&>*]:transition-all [&>*]:duration-300">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="keywords">Keywords</TabsTrigger>
            <TabsTrigger value="business-rules">Business Rules</TabsTrigger>
            <TabsTrigger value="report">Report</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Effort Trends</CardTitle>
                  <CardDescription>R&D effort over the last 30 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    <BarChart3 className="h-16 w-16" />
                    <span className="ml-4">Chart visualization would go here</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Top Keywords</CardTitle>
                  <CardDescription>Most frequently detected R&D keywords</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <KeywordItem keyword="Machine Learning" count={89} />
                    <KeywordItem keyword="Data Analysis" count={67} />
                    <KeywordItem keyword="Algorithm" count={54} />
                    <KeywordItem keyword="Research" count={43} />
                    <KeywordItem keyword="Innovation" count={32} />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>User Activity</CardTitle>
                  <CardDescription>R&D effort by team member</CardDescription>
                </div>
                <Dialog open={isCreateUserDialogOpen} onOpenChange={setIsCreateUserDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Create New User
                    </Button>
                  </DialogTrigger>
                  <CreateUserDialog onClose={() => setIsCreateUserDialogOpen(false)} />
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <UserActivityItem
                    name="Sarah Johnson"
                    role="Senior Researcher"
                    effort="156 hrs"
                    emails={89}
                    status="active"
                  />
                  <UserActivityItem
                    name="Mike Chen"
                    role="Data Scientist"
                    effort="134 hrs"
                    emails={76}
                    status="active"
                  />
                  <UserActivityItem
                    name="Emily Davis"
                    role="Research Analyst"
                    effort="98 hrs"
                    emails={54}
                    status="active"
                  />
                  <UserActivityItem
                    name="Alex Rodriguez"
                    role="ML Engineer"
                    effort="87 hrs"
                    emails={43}
                    status="warning"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="keywords" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Keyword Management</CardTitle>
                  <CardDescription>Configure R&D keywords and their weights</CardDescription>
                </div>
                <Dialog open={isCreateKeywordDialogOpen} onOpenChange={setIsCreateKeywordDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Create New
                    </Button>
                  </DialogTrigger>
                  <CreateKeywordDialog onClose={() => setIsCreateKeywordDialogOpen(false)} />
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <KeywordConfigItem
                    keyword="Artificial Intelligence"
                    weight={20}
                    category="Technology"
                    matches={156}
                  />
                  <KeywordConfigItem keyword="Machine Learning" weight={18} category="Technology" matches={134} />
                  <KeywordConfigItem keyword="Data Science" weight={15} category="Analytics" matches={98} />
                  <KeywordConfigItem keyword="Research Methodology" weight={12} category="Process" matches={67} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="business-rules" className="space-y-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Business Rules</CardTitle>
                  <CardDescription>Manage R&D effort calculation rules</CardDescription>
                </div>
                <Dialog open={isCreateBusinessRuleDialogOpen} onOpenChange={setIsCreateBusinessRuleDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="h-4 w-4 mr-2" />
                      Create New
                    </Button>
                  </DialogTrigger>
                  <CreateBusinessRuleDialog onClose={() => setIsCreateBusinessRuleDialogOpen(false)} />
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {businessRules.map((rule) => (
                    <BusinessRuleItem
                      key={rule.id}
                      rule={rule}
                      isEditing={editingBusinessRule === rule.id}
                      onEdit={() => handleEditBusinessRule(rule.id)}
                      onSave={() => handleSaveBusinessRule(rule.id)}
                      onCancel={handleCancelEdit}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="report" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Report</CardTitle>
                <CardDescription>View and export R&D activity data</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Date Range Filter */}
                  <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                    <Calendar className="h-5 w-5 text-gray-500" />
                    <div className="flex items-center space-x-2">
                      <Label htmlFor="date-from">From:</Label>
                      <Input
                        id="date-from"
                        type="date"
                        value={dateRange.from}
                        onChange={(e) => setDateRange((prev) => ({ ...prev, from: e.target.value }))}
                        className="w-40"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Label htmlFor="date-to">To:</Label>
                      <Input
                        id="date-to"
                        type="date"
                        value={dateRange.to}
                        onChange={(e) => setDateRange((prev) => ({ ...prev, to: e.target.value }))}
                        className="w-40"
                      />
                    </div>
                    <Button variant="outline" size="sm">
                      <Filter className="h-4 w-4 mr-2" />
                      Apply Filter
                    </Button>
                  </div>

                  {/* Download Buttons */}
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="select-all"
                        checked={reportData.every((row) => row.selected)}
                        onCheckedChange={handleSelectAll}
                      />
                      <Label htmlFor="select-all" className="text-sm font-medium">
                        Select All ({reportData.filter((row) => row.selected).length} selected)
                      </Label>
                    </div>
                    <div className="flex space-x-2">
                      <Button onClick={() => handleDownload("excel")} size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Download Excel
                      </Button>
                      <Button onClick={() => handleDownload("pdf")} size="sm" variant="outline">
                        <Download className="h-4 w-4 mr-2" />
                        Download PDF
                      </Button>
                    </div>
                  </div>

                  {/* Report Table */}
                  <div className="border rounded-lg overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Select
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Entity Type
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Date
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Sender
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Recipients
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Word Count
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Efforts (min)
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Keyword Count
                            </th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Keyword Efforts (min)
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {reportData.map((row) => (
                            <tr key={row.id} className="hover:bg-gray-50">
                              <td className="px-4 py-4 whitespace-nowrap">
                                <Checkbox
                                  checked={row.selected}
                                  onCheckedChange={(checked) => handleSelectRow(row.id, checked as boolean)}
                                />
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap">
                                <Badge variant={row.entityType === "Email" ? "default" : "secondary"}>
                                  {row.entityType}
                                </Badge>
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{row.date}</td>
                              <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{row.sender}</td>
                              <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{row.recipients}</td>
                              <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{row.wordCount}</td>
                              <td className="px-4 py-4 whitespace-nowrap">
                                <Input
                                  type="number"
                                  value={row.efforts}
                                  onChange={(e) =>
                                    handleEffortChange(row.id, "efforts", Number.parseInt(e.target.value))
                                  }
                                  className="w-20 text-sm"
                                />
                              </td>
                              <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{row.keywordCount}</td>
                              <td className="px-4 py-4 whitespace-nowrap">
                                <Input
                                  type="number"
                                  value={row.keywordEfforts}
                                  onChange={(e) =>
                                    handleEffortChange(row.id, "keywordEfforts", Number.parseInt(e.target.value))
                                  }
                                  className="w-20 text-sm"
                                />
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

function MetricCard({
  title,
  value,
  change,
  icon,
  trend,
}: {
  title: string
  value: string
  change: string
  icon: React.ReactNode
  trend: "up" | "down"
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className={`text-xs ${trend === "up" ? "text-green-600" : "text-red-600"}`}>
          <TrendingUp className="h-3 w-3 inline mr-1" />
          {change} from last month
        </p>
      </CardContent>
    </Card>
  )
}

function KeywordItem({ keyword, count }: { keyword: string; count: number }) {
  return (
    <div className="flex justify-between items-center">
      <span className="font-medium">{keyword}</span>
      <Badge variant="secondary">{count}</Badge>
    </div>
  )
}

function UserActivityItem({
  name,
  role,
  effort,
  emails,
  status,
}: {
  name: string
  role: string
  effort: string
  emails: number
  status: "active" | "warning"
}) {
  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div className="flex items-center space-x-4">
        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
          <Users className="h-5 w-5 text-blue-600" />
        </div>
        <div>
          <p className="font-medium">{name}</p>
          <p className="text-sm text-gray-600">{role}</p>
        </div>
      </div>
      <div className="text-right">
        <p className="font-medium">{effort}</p>
        <p className="text-sm text-gray-600">{emails} emails</p>
      </div>
      <Badge variant={status === "active" ? "default" : "destructive"}>{status}</Badge>
    </div>
  )
}

function KeywordConfigItem({
  keyword,
  weight,
  category,
  matches,
}: {
  keyword: string
  weight: number
  category: string
  matches: number
}) {
  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div>
        <p className="font-medium">{keyword}</p>
        <p className="text-sm text-gray-600">{category}</p>
      </div>
      <div className="flex items-center space-x-4">
        <div className="text-right">
          <p className="text-sm">Weight: {weight}min</p>
          <p className="text-sm text-gray-600">{matches} matches</p>
        </div>
        <Button size="sm" variant="outline">
          Edit
        </Button>
      </div>
    </div>
  )
}

function BusinessRuleItem({
  rule,
  isEditing,
  onEdit,
  onSave,
  onCancel,
}: {
  rule: { id: string; name: string; wordCount: number; efforts: number }
  isEditing: boolean
  onEdit: () => void
  onSave: () => void
  onCancel: () => void
}) {
  const [editedRule, setEditedRule] = useState(rule)

  useEffect(() => {
    setEditedRule(rule)
  }, [rule])

  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div className="flex-1 grid grid-cols-3 gap-4">
        {isEditing ? (
          <>
            <Input
              value={editedRule.name}
              onChange={(e) => setEditedRule((prev) => ({ ...prev, name: e.target.value }))}
              placeholder="Rule Name"
            />
            <Input
              type="number"
              value={editedRule.wordCount}
              onChange={(e) => setEditedRule((prev) => ({ ...prev, wordCount: Number.parseInt(e.target.value) }))}
              placeholder="Word Count"
            />
            <Input
              type="number"
              value={editedRule.efforts}
              onChange={(e) => setEditedRule((prev) => ({ ...prev, efforts: Number.parseInt(e.target.value) }))}
              placeholder="Efforts (min)"
            />
          </>
        ) : (
          <>
            <div>
              <p className="font-medium">{rule.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">{rule.wordCount} words</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">{rule.efforts} minutes</p>
            </div>
          </>
        )}
      </div>
      <div className="flex items-center space-x-2 ml-4">
        {isEditing ? (
          <>
            <Button size="sm" onClick={onSave}>
              <Save className="h-4 w-4" />
            </Button>
            <Button size="sm" variant="outline" onClick={onCancel}>
              <X className="h-4 w-4" />
            </Button>
          </>
        ) : (
          <Button size="sm" variant="outline" onClick={onEdit}>
            <Edit className="h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  )
}

function CreateUserDialog({ onClose }: { onClose: () => void }) {
  const [state, formAction] = useActionState(createUserAndMailCredentials, {
    success: false,
    message: "",
    errors: {},
  })
  const { pending } = useFormStatus()
  const { toast } = useToast()

  useEffect(() => {
    if (state.message) {
      toast({
        title: state.success ? "Success!" : "Error!",
        description: state.message,
        variant: state.success ? "default" : "destructive",
      })
      if (state.success) {
        onClose() // Close dialog on successful creation
      }
    }
  }, [state, toast, onClose])

  return (
    <DialogContent className="sm:max-w-[425px]">
      <DialogHeader>
        <DialogTitle>Create New User</DialogTitle>
        <DialogDescription>
          Enter user details. Temporary credentials will be generated and simulated to be emailed.
        </DialogDescription>
      </DialogHeader>
      <form action={formAction}>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Name
            </Label>
            <Input id="name" name="name" className="col-span-3" required />
            {state.errors?.name && <p className="col-span-4 text-right text-sm text-red-500">{state.errors.name}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="email" className="text-right">
              Email
            </Label>
            <Input id="email" name="email" type="email" className="col-span-3" required />
            {state.errors?.email && <p className="col-span-4 text-right text-sm text-red-500">{state.errors.email}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="role" className="text-right">
              Role
            </Label>
            <Select name="role" required>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Select a role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="user">User</SelectItem>
              </SelectContent>
            </Select>
            {state.errors?.role && <p className="col-span-4 text-right text-sm text-red-500">{state.errors.role}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="department" className="text-right">
              Department
            </Label>
            <Input id="department" name="department" className="col-span-3" />
            {state.errors?.department && (
              <p className="col-span-4 text-right text-sm text-red-500">{state.errors.department}</p>
            )}
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={pending}>
            {pending ? "Creating..." : "Create User"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  )
}

function CreateKeywordDialog({ onClose }: { onClose: () => void }) {
  return (
    <DialogContent className="sm:max-w-[425px]">
      <DialogHeader>
        <DialogTitle>Create New Keyword</DialogTitle>
        <DialogDescription>Add a new R&D keyword with its configuration.</DialogDescription>
      </DialogHeader>
      <div className="grid gap-4 py-4">
        <div className="grid grid-cols-4 items-center gap-4">
          <Label htmlFor="keyword" className="text-right">
            Keyword
          </Label>
          <Input id="keyword" className="col-span-3" placeholder="Enter keyword" />
        </div>
        <div className="grid grid-cols-4 items-center gap-4">
          <Label htmlFor="weight" className="text-right">
            Weight (min)
          </Label>
          <Input id="weight" type="number" className="col-span-3" placeholder="Enter weight" />
        </div>
        <div className="grid grid-cols-4 items-center gap-4">
          <Label htmlFor="category" className="text-right">
            Category
          </Label>
          <Select>
            <SelectTrigger className="col-span-3">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="technology">Technology</SelectItem>
              <SelectItem value="analytics">Analytics</SelectItem>
              <SelectItem value="process">Process</SelectItem>
              <SelectItem value="research">Research</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <DialogFooter>
        <Button onClick={onClose}>Create Keyword</Button>
      </DialogFooter>
    </DialogContent>
  )
}

function CreateBusinessRuleDialog({ onClose }: { onClose: () => void }) {
  return (
    <DialogContent className="sm:max-w-[425px]">
      <DialogHeader>
        <DialogTitle>Create New Business Rule</DialogTitle>
        <DialogDescription>Define a new rule for R&D effort calculation.</DialogDescription>
      </DialogHeader>
      <div className="grid gap-4 py-4">
        <div className="grid grid-cols-4 items-center gap-4">
          <Label htmlFor="rule-name" className="text-right">
            Rule Name
          </Label>
          <Input id="rule-name" className="col-span-3" placeholder="Enter rule name" />
        </div>
        <div className="grid grid-cols-4 items-center gap-4">
          <Label htmlFor="word-count" className="text-right">
            Word Count
          </Label>
          <Input id="word-count" type="number" className="col-span-3" placeholder="Enter word count" />
        </div>
        <div className="grid grid-cols-4 items-center gap-4">
          <Label htmlFor="efforts" className="text-right">
            Efforts (min)
          </Label>
          <Input id="efforts" type="number" className="col-span-3" placeholder="Enter efforts in minutes" />
        </div>
      </div>
      <DialogFooter>
        <Button onClick={onClose}>Create Rule</Button>
      </DialogFooter>
    </DialogContent>
  )
}
