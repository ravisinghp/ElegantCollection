import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight, User, UserCog, Zap } from "lucide-react"

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo/Brand Section */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-2xl mb-4 shadow-lg">
            <Zap className="h-8 w-8 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-heading font-bold text-foreground mb-2">R&D Estimator</h1>
          <p className="text-muted-foreground">Intelligent effort tracking for research teams</p>
        </div>

        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-heading font-bold">Welcome Back</CardTitle>
            <CardDescription>Choose your role to access the dashboard</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <Button asChild className="w-full py-6 text-lg shadow-md hover:shadow-lg transition-all duration-300">
                <Link href="/dashboard/admin" className="flex items-center justify-center">
                  <UserCog className="h-6 w-6 mr-3" />
                  Sign In as Admin
                  <ArrowRight className="ml-auto h-5 w-5" />
                </Link>
              </Button>

              <Button
                asChild
                variant="outline"
                className="w-full py-6 text-lg transition-all duration-300 bg-transparent"
              >
                <Link href="/dashboard/user" className="flex items-center justify-center">
                  <User className="h-6 w-6 mr-3" />
                  Sign In as User
                  <ArrowRight className="ml-auto h-5 w-5" />
                </Link>
              </Button>
            </div>

            <div className="pt-4 border-t">
              <p className="text-center text-sm text-muted-foreground">
                By signing in, you agree to our{" "}
                <Link href="#" className="text-primary hover:underline transition-colors">
                  Terms of Service
                </Link>{" "}
                and{" "}
                <Link href="#" className="text-primary hover:underline transition-colors">
                  Privacy Policy
                </Link>
                .
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-muted-foreground text-sm">Powered by AI-driven research analytics</p>
        </div>
      </div>
    </div>
  )
}
